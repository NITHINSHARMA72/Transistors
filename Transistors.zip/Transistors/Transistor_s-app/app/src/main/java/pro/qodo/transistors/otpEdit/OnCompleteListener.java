package pro.qodo.transistors.otpEdit;

/**
 * Created by Swapnil Tiwari on 2019-07-28.
 * swapnil.tiwari@box8.in
 */
public interface OnCompleteListener {

    void onComplete(String value);

}
