package pro.qodo.transistors;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import pro.qodo.transistors.items.Message;
import pro.qodo.transistors.items.User;



public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.VH> {

    List<Message> matList;
    private Context context;
    View view;
    User user;
    private static MessageAdapter.OnItemClickListener mListener;


    public interface OnItemClickListener {

        void onItemClick(int position);

        void onItemDeleteClicked(int position);

        void onNameClicked (int position);

    }


    public MessageAdapter(List<Message> matList, Activity activity , User user) {
        this.matList = matList;
        this.context = activity;
        this.user = user;

        setHasStableIds(false);
    }


    @Override
    public MessageAdapter.VH onCreateViewHolder(ViewGroup parent, int viewType) {

        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_item, parent, false);

        return new MessageAdapter.VH(view);
    }


    @Override
    public int getItemCount() {
        return matList.size();
    }


    @Override
    public void onBindViewHolder(MessageAdapter.VH holder, int position) {

        holder.textMessage.setText(matList.get(position).getmText());

        try {

            String userN = matList.get(position).getmUser().fetchIfNeeded().getString("nickname");
            holder.userName.setText(userN);

        } catch (com.parse.ParseException e) {
            e.printStackTrace();
        }

        holder.txt_date.setText(matList.get(position).getTimeInfo());

        if (user != null && user.getUserAsAdmin()) {

           holder.btn_delete.setVisibility(View.VISIBLE);

        } else {

            holder.btn_delete.setVisibility(View.GONE);
        }



    }


    public static class VH extends RecyclerView.ViewHolder {

        TextView textMessage;
        TextView userName;
        TextView txt_date;

        Button btn_delete;


        public VH(View itemView) {
            super(itemView);

            textMessage = (TextView) itemView.findViewById(R.id.textMessage);
            userName = (TextView) itemView.findViewById(R.id.username);
            txt_date = (TextView) itemView.findViewById(R.id.txt_date);
            btn_delete = (Button) itemView.findViewById(R.id.button_delete);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (mListener != null) mListener.onItemClick(getAdapterPosition());

                    if (getAdapterPosition() == RecyclerView.NO_POSITION) return;

                }
            });

            btn_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (mListener != null) {
                        mListener.onItemDeleteClicked(getAdapterPosition());
                    }
                }
            });

            userName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (mListener != null) {
                        mListener.onNameClicked(getAdapterPosition());
                    }
                }
            });

        }

    }


    public void setOnItemClickListener(MessageAdapter.OnItemClickListener listener) {
        this.mListener = listener;
    }



}


