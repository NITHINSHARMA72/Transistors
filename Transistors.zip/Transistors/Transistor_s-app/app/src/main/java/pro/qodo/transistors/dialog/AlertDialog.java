package pro.qodo.transistors.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatDialog;

import pro.qodo.transistors.R;



public class AlertDialog extends AppCompatDialog implements
        View.OnClickListener {

    public Context df;
    public Dialog dr;
    TextView text;
    Button ok;
    String alert;

    public AlertDialog(Context a, String alert) {
        super(a);
        this.df = a;
        this.alert = alert;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.alert_dialog);
        text = (TextView) findViewById(R.id.errorText);
        ok = (Button) findViewById(R.id.btn_ook);
        text.setText(alert);
        getWindow().setGravity(Gravity.CENTER);
        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_ook:
                // c.finish();
                break;

            default:
                break;
        }
        dismiss();
    }
}

