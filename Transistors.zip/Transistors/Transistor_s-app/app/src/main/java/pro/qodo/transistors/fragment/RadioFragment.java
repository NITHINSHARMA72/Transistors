package pro.qodo.transistors.fragment;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.palette.graphics.Palette;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import com.appizona.yehiahd.fastsave.FastSave;
import com.bumptech.glide.Glide;
import com.flaviofaria.kenburnsview.KenBurnsView;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;
import com.parse.livequery.ParseLiveQueryClient;
import com.parse.livequery.SubscriptionHandling;
import com.rishabhharit.roundedimageview.RoundedImageView;
import com.sdsmdg.harjot.crollerTest.Croller;
import com.sdsmdg.harjot.crollerTest.OnCrollerChangeListener;
import com.thekhaeng.pushdownanim.PushDownAnim;
import com.yashovardhan99.timeit.Stopwatch;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import pro.qodo.transistors.MainActivity;
import pro.qodo.transistors.MessageAdapter;
import pro.qodo.transistors.R;
import pro.qodo.transistors.UpActivity;
import pro.qodo.transistors.dialog.AlertDialog;
import pro.qodo.transistors.dialog.BannUserDialog;
import pro.qodo.transistors.dialog.LoginDialog;
import pro.qodo.transistors.helpers.MessageCover;
import pro.qodo.transistors.helpers.MessageTitle;
import pro.qodo.transistors.helpers.ShareHelper;
import pro.qodo.transistors.items.Banned;
import pro.qodo.transistors.items.Message;
import pro.qodo.transistors.items.Radio;
import pro.qodo.transistors.items.User;
import pro.qodo.transistors.prfs.MessageEvent;
import pro.qodo.transistors.prfs.OnSwipeTouchListener;
import pro.qodo.transistors.prfs.Prfs;
import pro.qodo.transistors.prfs.Rstring;
import pro.qodo.transistors.rh.PlaybackStatus;
import pro.qodo.transistors.rh.RadioService;
import pro.qodo.transistors.rh.Recorder;
import pro.qodo.transistors.singleton.RadioGlobal;


/**
 * A simple {@link Fragment} subclass.
 */
public class RadioFragment extends Fragment implements Prfs, Stopwatch.OnTickListener {

    View rootView;
    String LOG_TAG = "Log";
    List<Message> mList = new ArrayList<>();
    @BindView(R.id.playTrigger)
    Button trigger;
    @BindView(R.id.radioname)
    TextView title_text;
    @BindView(R.id.r_image)
    RoundedImageView motion_cover;
    @BindView(R.id.nms)
    TextView namestation;
    @BindView(R.id.share)
    Button share_btn;
    @BindView(R.id.comment)
    Button comment;
    @BindView(R.id.chat_layout)
    RelativeLayout chat_layout;
    @BindView(R.id.down_view)
    Button down_view;
    @BindView(R.id.btn_send)
    Button send_button;
    @BindView(R.id.send_txt)
    EditText send_txt;
    @BindView(R.id.show_message)
    RecyclerView show_message;

    @BindView(R.id.txt_song)
    TextView song_text;
    @BindView(R.id.artist_txt)
    TextView artist_txt;

    @BindView(R.id.btn_record)
    Button record_btn;
    @BindView(R.id.record_label)
    TextView record_label;


    String urlRadio;
    Radio radio;
    Boolean isPlaing;
    User user;
    boolean isUp;
    Boolean isOpen = false;
    MessageAdapter messageAdapter;
    private LinearLayoutManager layoutManager;
    String nameStation;
    Boolean iDle;
    Bitmap artImage;
    Recorder recorder;
    String song_name;
    Stopwatch stopwatch;
    String record_time;
    ParseLiveQueryClient parseLiveQueryClient;
    SubscriptionHandling<Message> subscriptionHandling;
    int positionRemove;
    Boolean bannedCurrentUser;
    private AudioManager audioManager = null;
    Intent radioServiseIntent;
    FragmentManager fragmentManager;



    public RadioFragment() {
    }


    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_radio, container, false);
        ButterKnife.bind(this, rootView);

        iDle = false;
        record_label.setVisibility(View.GONE);



        stopwatch = new Stopwatch();

        stopwatch.setTextView(record_label);






        record_label.setSelected(true);

        try {

            parseLiveQueryClient = ParseLiveQueryClient.Factory.getClient(new URI(Prfs.LIVE_QUERY_HOSTING));

        } catch (URISyntaxException ex) {

        }

        ParseQuery<Message> parseQuery = ParseQuery.getQuery(Message.class);

        subscriptionHandling = parseLiveQueryClient.subscribe(parseQuery);

        subscriptionHandling.handleEvent(SubscriptionHandling.Event.CREATE, new SubscriptionHandling.HandleEventCallback<Message>() {
            @Override
            public void onEvent(ParseQuery<Message> query, Message message) {
                // HANDLING create event

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        mList.add(message);
                        messageAdapter.notifyDataSetChanged();
                        show_message.scrollToPosition(mList.size() - 1);
                    }
                });

            }

        });

        subscriptionHandling.handleEvent(SubscriptionHandling.Event.DELETE, new SubscriptionHandling.HandleEventCallback<Message>() {
            @Override
            public void onEvent(ParseQuery<Message> query, Message message) {

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        mList.clear();
                        getMessage();
                    }
                });

            }

        });


        user = (User) ParseUser.getCurrentUser();

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                .permitAll().build();
        StrictMode.setThreadPolicy(policy);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        radio = RadioGlobal.getInstance().getRadio();
        urlRadio = radio.getrUrl();



        namestation.setSelected(true);

        isUp = false;
        slidestart(chat_layout);

        layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        layoutManager.setReverseLayout(false);
        show_message.setLayoutManager(layoutManager);



        chat_layout.setOnTouchListener(new OnSwipeTouchListener(getActivity()) {
            public void onSwipeTop() {
                slideUp(chat_layout);
                isOpen = true;
            }


            public void onSwipeBottom() {
                slideDown(chat_layout);
                isOpen = false;
            }

        });




        PushDownAnim.setPushDownAnimTo(trigger)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                       // RADIO START
                        radioServiseIntent = new Intent(requireActivity(), RadioService.class);

                        if (RadioService.getInstance() != null) {

                            if(RadioService.getInstance().isPlaying()){

                                Intent stop = new Intent(requireActivity(), RadioService.class);
                                stop.setAction(RadioService.ACTION_STOP);
                                requireActivity().startService(stop);
                            } else {
                                String playerCurrentRadio = RadioService.getInstance().getPlayingRadioStation();
                                if (playerCurrentRadio != null) {

                                    RadioService.getInstance().inits(requireActivity(), urlRadio);
                                    radioServiseIntent.setAction(RadioService.ACTION_PLAY);

                                } else {
                                    RadioService.getInstance().inits(requireActivity(), urlRadio);
                                    radioServiseIntent.setAction(RadioService.ACTION_PLAY);
                                }
                            }

                        } else {
                            RadioService.createInstance().inits(requireActivity(), urlRadio);
                            radioServiseIntent.setAction(RadioService.ACTION_PLAY);
                        }
                        requireActivity().startService(radioServiseIntent);


                    }

                });

        PushDownAnim.setPushDownAnimTo(share_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ShareHelper shareHelper = new ShareHelper();
                shareHelper.shareIt(artImage,song_name,requireContext());

            }
        });

        PushDownAnim.setPushDownAnimTo(comment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                slideUp(chat_layout);

            }
        });

        PushDownAnim.setPushDownAnimTo(down_view).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                slideDown(chat_layout);

            }
        });

        send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (user != null) {

                    if (bannedCurrentUser) {

                        final AlertDialog alertDialog = new AlertDialog(getActivity(), "You banned !!!");
                        alertDialog.show();
                        alertDialog.findViewById(R.id.btn_ook).setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                alertDialog.dismiss();
                                send_txt.setText("");
                            }
                        });

                    } else {

                        Message message = new Message();
                        message.setmUser(user);
                        message.setmText(send_txt.getText().toString());
                        message.saveInBackground(new SaveCallback() {
                            @Override
                            public void done(ParseException e) {

                                send_txt.setText("");

                            }
                        });
                    }

                } else {

                    loginDialog();

                }

            }
        });

        getMessage();

        if(AUTOSTART){
            if (RadioService.getInstance() != null) {
                if(RadioService.getInstance().isPlaying()){
                    //  RadioService.getInstance().inits(requireActivity(), urlRadio);
                    //  requireActivity().startService(radioServiseIntent);
                }
            } else {

                radioServiseIntent = new Intent(requireActivity(), RadioService.class);
                RadioService.createInstance().inits(requireActivity(), urlRadio);
                radioServiseIntent.setAction(RadioService.ACTION_PLAY);
                requireActivity().startService(radioServiseIntent);
            }

        }

        requireActivity().setVolumeControlStream(AudioManager.STREAM_MUSIC);
        audioManager = (AudioManager) requireActivity().getSystemService(Context.AUDIO_SERVICE);


        record_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (recorder != null) {   // recordel full

                    if (recorder.isRecording()) {  // recorded on

                        recorder.stopRecording();
                        record_btn.setBackground(getResources().getDrawable(R.drawable.record_b_g));
                        recorder = null;
                        record_btn.clearAnimation();
                        record_label.setVisibility(View.GONE);

                        if (stopwatch.isStarted())
                            stopwatch.stop();

                    }

                } else {

                    if (song_name == null) {

                    } else {

                        String tlt = song_name.replace(" ", "_");
                        String tld = tlt.replace("/", "_");
                        String currentTime = new SimpleDateFormat("ss", Locale.getDefault()).format(new Date());
                        String rnd_title = currentTime + "-XYZ-" + tld + ".mp3";

                        recorder = new Recorder(getContext(), urlRadio, rnd_title);
                        recorder.record();
                        record_btn.setBackground(getResources().getDrawable(R.drawable.record_b_r));
                        record_label.setVisibility(View.VISIBLE);
                        // record_label.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.blink));
                        record_btn.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.rotate));

                        if (!stopwatch.isStarted()) {
                            stopwatch.start();

                        }

                    }

                }

            }
        });

        getBannedUser();

        return rootView;
    }





    private void getBannedUser() {

        ParseQuery<Banned> bnQuery = Banned.getBannedUser();
        bnQuery.whereEqualTo(Banned.BANNED_USER, user);
        bnQuery.findInBackground(new FindCallback<Banned>() {
            @Override
            public void done(List<Banned> objects, ParseException e) {

                if (e == null) {

                    if (objects.size() == 0) {

                        bannedCurrentUser = false;

                    } else {

                        bannedCurrentUser = true;

                    }
                }
            }
        });
    }


    private void getMessage() {

        ParseQuery<Message> mQuery = Message.getParseMessage();
        mQuery.include(Message.M_USER);
        mQuery.findInBackground(new FindCallback<Message>() {
            @Override
            public void done(List<Message> objects, ParseException e) {

                if (e == null) {

                    mList = objects;
                    buildMessage();
                }
            }
        });

    }


    private void buildMessage() {

        ((SimpleItemAnimator) show_message.getItemAnimator()).setSupportsChangeAnimations(true);
        messageAdapter = new MessageAdapter(mList, getActivity(), user);
        show_message.setAdapter(messageAdapter);
        show_message.setHasFixedSize(true);
        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getActivity(), resId);
        show_message.setLayoutAnimation(animation);
        show_message.scrollToPosition(mList.size() - 1);

        messageAdapter.setOnItemClickListener(new MessageAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }


            @Override
            public void onItemDeleteClicked(int position) {

                Message message = mList.get(position);
                message.deleteEventually();
                positionRemove = position;

            }


            @Override
            public void onNameClicked(int position) {

                if (user != null && user.getUserAsAdmin()) {

                    final BannUserDialog bannUserDialog = new BannUserDialog(getActivity());
                    bannUserDialog.show();
                    bannUserDialog.findViewById(R.id.btn_reply).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            Message m = mList.get(position);
                            String name = m.getmUser().getUserNikname();
                            send_txt.setText("@" + name + ", ");
                            bannUserDialog.dismiss();
                        }
                    });
                    bannUserDialog.findViewById(R.id.btn_bann).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            ParseQuery<Banned> bQuery = Banned.getBannedUser();
                            bQuery.whereEqualTo(Banned.BANNED_USER, mList.get(position).getmUser());
                            bQuery.findInBackground(new FindCallback<Banned>() {
                                @Override
                                public void done(List<Banned> objects, ParseException e) {

                                    if (e == null) {

                                        if (objects.size() == 0) {

                                            Banned banned = new Banned();
                                            banned.setBannedUser(mList.get(position).getmUser());
                                            banned.saveInBackground(new SaveCallback() {
                                                @Override
                                                public void done(ParseException e) {

                                                    bannUserDialog.dismiss();
                                                }
                                            });
                                        }
                                    }
                                }
                            });

                        }
                    });

                } else {

                    Message m = mList.get(position);
                    String name = m.getmUser().getUserNikname();
                    send_txt.setText("@" + name + ", ");
                }

            }
        });

    }


    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }








    public void slidestart(View view) {

        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, "translationY", 2000);
        objectAnimator.setDuration(0);
        objectAnimator.start();

    }


    public void slideUp(View view) {

        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, "translationY", 0);
        objectAnimator.setDuration(500);
        objectAnimator.start();

    }


    // slide the view from its current position to below itself
    public void slideDown(View view) {

        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, "translationY", 2000);
        objectAnimator.setDuration(500);
        objectAnimator.start();
        hideKeyboard(getActivity());


    }


    private void loginDialog() {

        final LoginDialog login = new LoginDialog(getActivity(), getString(R.string.register_now));
        login.show();
        login.findViewById(R.id.sign_up).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getActivity(), UpActivity.class);
                startActivity(intent);
                getActivity().overridePendingTransition(R.anim.slide_up, R.anim.slide_bottom);
                login.dismiss();
            }
        });

    }







    @Subscribe
    public void onEvent(MessageTitle event) {

        // makeScreenUpdate(event.message, event.bitmap, event.radioName);

        song_text.setText(event.message);
        song_name = event.message;


    }

    @Subscribe
    public void onEvent(MessageCover event) {
        // makeScreenUpdate(event.message, event.bitmap, event.radioName);

        System.out.println("EVENT = = = A " +event.cover );

        if(artImage.equals(event.bitmap)){

            System.out.println("EVENT = = = EQ " );

        }



        motion_cover.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_out));
        artImage = event.bitmap;

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Glide.with(requireActivity())
                        .load(event.cover)
                        .into(motion_cover);

                motion_cover.startAnimation(AnimationUtils.loadAnimation(getContext(), R.anim.fade_in));
                Palette.from(event.bitmap).generate(new Palette.PaletteAsyncListener() {
                    @Override
                    public void onGenerated(Palette palette) {
                        ((MainActivity) getActivity()).changeBack(palette);
                    }
                });




            }
        }, 50);


    }



    @Subscribe
    public void onEvent(final String status) {

        switch (status) {

            case PlaybackStatus.LOADING:

                break;

            case PlaybackStatus.ERROR:

                FastSave.getInstance().saveBoolean("play", false);

                break;

            case PlaybackStatus.STOPPED:

                FastSave.getInstance().saveBoolean("play", false);

                break;
            case PlaybackStatus.IDLE:
                iDle = true;

                break;
            case PlaybackStatus.PAUSED:



                FastSave.getInstance().saveBoolean("play", false);
                break;

            case PlaybackStatus.PLAYING:

                FastSave.getInstance().saveBoolean("play", true);


                break;

        }

        trigger.setBackground(status.equals(PlaybackStatus.PLAYING) ? ContextCompat.getDrawable(getActivity(), R.drawable.pausebtn) : ContextCompat.getDrawable(getActivity(), R.drawable.playbtn));


    }


    @Override
    public void onResume() {



        if(RadioService.getInstance() != null) {

            title_text.setText(Prfs.APPNAME);

            song_text.setText(FastSave.getInstance().getString(Prfs.TITLE_RADIO,""));
            Glide.with(requireActivity())
                    .load(FastSave.getInstance().getString(Prfs.COVER_RADIO,""))
                    .into(motion_cover);
            trigger.setBackground(getResources().getDrawable(R.drawable.pausebtn));
          //  Palette.from(getBitmapsFromURL(FastSave.getInstance().getString(Prfs.COVER_RADIO,""))).generate(new Palette.PaletteAsyncListener() {
           //     @Override
            //    public void onGenerated(Palette palette) {
             //       ((MainActivity) getActivity()).changeBack(palette);
             //   }
           // });





        } else {
            title_text.setText(Prfs.APPNAME);

            song_text.setText("...");
            Glide.with(requireActivity())
                    .load(Prfs.COVER)
                    .into(motion_cover);
            trigger.setBackground(getResources().getDrawable(R.drawable.playbtn));
            Palette.from(getBitmapsFromURL(Prfs.COVER)).generate(new Palette.PaletteAsyncListener() {
                @Override
                public void onGenerated(Palette palette) {
                    ((MainActivity) getActivity()).changeBack(palette);
                }
            });
        }


        super.onResume();



    }





    @Override
    public void onPause() {
        super.onPause();
        // super.onDestroyView();
    }


    @Override
    public void onDestroy() {

      //  EventBus.getDefault().unregister(this);
        RadioService.getInstance().stopExoPlayer();

        super.onDestroy();

    }


    @Override
    public void onStop() {

        EventBus.getDefault().unregister(this);
        super.onStop();

    }


    @Override
    public void onStart() {

        EventBus.getDefault().register(this);
        super.onStart();

    }


    @Override
    public void onTick(Stopwatch stopwatch) {
        Log.d("MAINACTIVITYLISTENER", String.valueOf(stopwatch.getElapsedTime()));
    }
    public static Bitmap getBitmapsFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            // Log exception
            return null;
        }
    }

}


