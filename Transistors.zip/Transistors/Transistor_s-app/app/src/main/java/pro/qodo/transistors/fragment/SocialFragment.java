package pro.qodo.transistors.fragment;

import android.annotation.TargetApi;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import butterknife.BindView;
import butterknife.ButterKnife;
import lib.kingja.switchbutton.SwitchMultiButton;
import pro.qodo.transistors.R;
import pro.qodo.transistors.prfs.JavaScriptInterface;
import pro.qodo.transistors.prfs.Prfs;



/**
 * A simple {@link Fragment} subclass.
 */
public class SocialFragment extends Fragment implements Prfs {

    View rootView;
    @BindView(R.id.webView)
    WebView webView;
    @BindView(R.id.switchmultibutton)
    SwitchMultiButton switchMultiButton;
    String URL;
    private JavaScriptInterface javaScriptInterface;


    public SocialFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_social, container, false);
        ButterKnife.bind(this, rootView);

        URL = "http://yandex.ru";

        switchMultiButton.setSelectedTab(0);
        switchMultiButton.setOnSwitchListener(new SwitchMultiButton.OnSwitchListener() {
            @Override
            public void onSwitch(int position, String tabText) {

                switch (position) {
                    case 0:
                        runWebview(W_FB);
                        break;
                    case 1:
                        runWebview(W_TW);
                        break;
                    case 2:
                        runWebview(W_SITE);
                        break;
                    default:
                        break;
                }

            }
        });
        runWebview(W_FB);

        return rootView;
    }


    private void runWebview(String url) {

        String INTERFACE_NAME = "Android";

        webView.setWebViewClient(new WebViewClient() {
            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(getActivity(), description, Toast.LENGTH_SHORT).show();
            }


            @TargetApi(android.os.Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError rerr) {
                onReceivedError(view, rerr.getErrorCode(), rerr.getDescription().toString(), req.getUrl().toString());
            }
        });

        webView.loadUrl(url);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());

        javaScriptInterface = new JavaScriptInterface(getActivity());
        webView.addJavascriptInterface(javaScriptInterface, INTERFACE_NAME);

    }

}
