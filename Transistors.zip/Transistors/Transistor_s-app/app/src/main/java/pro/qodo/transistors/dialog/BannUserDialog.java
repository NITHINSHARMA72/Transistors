package pro.qodo.transistors.dialog;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import androidx.appcompat.app.AppCompatDialog;

import pro.qodo.transistors.R;



public class BannUserDialog extends AppCompatDialog implements
        View.OnClickListener {

    public Activity df;
    Button btn_bann;
    Button btn_reply;


    public BannUserDialog(Activity a) {
        super(a);
        this.df = a;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.bann_dialog);
        btn_bann = (Button) findViewById(R.id.btn_bann);
        btn_reply = (Button) findViewById(R.id.btn_reply);

        getWindow().setGravity(Gravity.CENTER);

        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_bann:
                break;
            case R.id.btn_reply:
                break;

            default:
                break;
        }
        dismiss();
    }

}


