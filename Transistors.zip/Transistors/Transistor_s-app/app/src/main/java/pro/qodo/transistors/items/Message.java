package pro.qodo.transistors.items;

import android.text.TextUtils;

import com.parse.ParseClassName;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;



@ParseClassName("Message")
public class Message extends ParseObject {

    public static String M_USER = "user";
    public static String M_MESSAGE = "message";


    public static ParseQuery<Message> getParseMessage() {
        return new ParseQuery<Message>(Message.class);
    }


    public User getmUser() {

        return (User) this.getParseUser(M_USER);
    }


    public void setmUser(User user) {

        put(M_USER, user);
    }


    public String getmText() {

        return this.getString(M_MESSAGE);
    }


    public void setmText(String txt) {

        put(M_MESSAGE, txt);
    }


    public String getTimeInfo() {
        Date messageDate = this.getCreatedAt();
        SimpleDateFormat sdf = null;
        if (isToday(messageDate)) {
            sdf = new SimpleDateFormat("HH:mm");
        } else {
            sdf = new SimpleDateFormat("dd-MMM, HH:mm");
        }
        String time = sdf.format(messageDate);
        return time;
    }


    public boolean isToday(Date date) {
        Calendar calendar = Calendar.getInstance();
        Date today = calendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        return TextUtils.equals(sdf.format(today), sdf.format(date));
    }

}
