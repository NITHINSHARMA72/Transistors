package pro.qodo.transistors.Callback;


import java.util.ArrayList;

import pro.qodo.transistors.items.Cover;


public class CallbackAlbumArt {

    public int resultCount = -1;
    public ArrayList<Cover> results = new ArrayList<>();

}
