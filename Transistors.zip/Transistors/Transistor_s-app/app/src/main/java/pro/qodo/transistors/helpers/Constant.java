package pro.qodo.transistors.helpers;

import com.google.android.exoplayer2.SimpleExoPlayer;

import java.io.Serializable;

public class Constant implements Serializable {

    private static final long serialVersionUID = 1L;

    public static String metadata;
    public static SimpleExoPlayer simpleExoPlayer;
    public static Boolean is_playing = false;
    public static String radioName;



}