package pro.qodo.transistors;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.palette.graphics.Palette;

import com.appizona.yehiahd.fastsave.FastSave;
import com.fxn.BubbleTabBar;
import com.fxn.OnBubbleClickListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.jaeger.library.StatusBarUtil;
import com.parse.ParseUser;

import butterknife.BindView;
import butterknife.ButterKnife;
import pro.qodo.transistors.dialog.LoginDialog;
import pro.qodo.transistors.fragment.NoInternetFragment;
import pro.qodo.transistors.fragment.RadioFragment;
import pro.qodo.transistors.fragment.RecordsFragment;
import pro.qodo.transistors.fragment.SettingsFragment;
import pro.qodo.transistors.fragment.SocialFragment;
import pro.qodo.transistors.fragment.UserFragment;
import pro.qodo.transistors.helpers.AdmobHelperr;
import pro.qodo.transistors.items.User;
import pro.qodo.transistors.prfs.Md5Class;
import pro.qodo.transistors.prfs.Prfs;



public class MainActivity extends BaseActivity implements Prfs {

    @BindView(R.id.bubbleTabBar)
    BubbleTabBar bubbleTabBar;
    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.view_need_offset)
    View mViewNeedOffset;
    @BindView(R.id.main)
    RelativeLayout main;

    @BindView(R.id.ads)
    LinearLayout ads_lay;
    FragmentTransaction fTrans;
    RadioFragment radioFragmen;
    SocialFragment socialFragment;
    UserFragment userFragment;
    SettingsFragment settingsFragment;
    RecordsFragment recordsFragment;
    NoInternetFragment noInternetFragment;
    String deviceId;
    Md5Class md5Class;
    AdRequest adRequest;
    User user;
    Boolean isOpen = false;
    Boolean isInternet;
    private static final int rID = 1;
    String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE

    };


    @Override
    public void finishActivity(int requestCode) {
        super.finishActivity(requestCode);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        user = (User) ParseUser.getCurrentUser();

        isInternet = FastSave.getInstance().getBoolean("internet", false);

        ActivityCompat.requestPermissions(this, PERMISSIONS, rID);

        bubbleTabBar = (BubbleTabBar) findViewById(R.id.bubbleTabBar);
        bubbleTabBar.addBubbleListener(new OnBubbleClickListener() {
            @Override
            public void onBubbleClick(int i) {

                switch (i) {
                    case (R.id.nav_radio):

                        if (!isOpen) {
                            goRadio();
                            isOpen = true;
                        }

                        break;
                    case (R.id.nav_social):
                        goSocial();
                        isOpen = false;
                        break;
                    case (R.id.nav_user):

                        if (user != null) {
                            goToUser();
                            isOpen = false;
                        } else {

                            LoginDialog l = new LoginDialog(MainActivity.this, getString(R.string.register_now));
                            l.show();
                            l.findViewById(R.id.sign_up).setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    Intent intent = new Intent(MainActivity.this, UpActivity.class);
                                    startActivity(intent);
                                    overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
                                    l.dismiss();
                                }
                            });

                        }

                        break;

                    case (R.id.nav_record):
                        goRecords();
                        isOpen = false;

                        break;

                    case (R.id.nav_settings):

                        goAbout();
                        isOpen = false;

                        break;
                }
            }
        });

        bubbleTabBar.setSelected(0, true);

        StatusBarUtil.setTranslucentForImageView(MainActivity.this, 0, mViewNeedOffset);
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mViewNeedOffset = findViewById(R.id.view_need_offset);

        setSupportActionBar(mToolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }

        setTitle("");
        AdmobHelperr admobHelperr = new AdmobHelperr();
        admobHelperr.setsAdmob(this,ads_lay);




    }


    private void goRadio() {

        if (isInternet) {

            radioFragmen = new RadioFragment();
            fTrans = getSupportFragmentManager().beginTransaction();
            fTrans.replace(R.id.content, radioFragmen);
            fTrans.addToBackStack(null);
            fTrans.show(radioFragmen);
            fTrans.commit();

        } else {

            noInternetFragment = new NoInternetFragment();
            fTrans = getSupportFragmentManager().beginTransaction();
            fTrans.replace(R.id.content, noInternetFragment);
            fTrans.addToBackStack(null);
            fTrans.show(noInternetFragment);
            fTrans.commit();

        }

    }


    private void goSocial() {

        if (isInternet) {

            socialFragment = new SocialFragment();
            fTrans = getSupportFragmentManager().beginTransaction();
            fTrans.replace(R.id.content, socialFragment);
            fTrans.addToBackStack(null);
            fTrans.show(socialFragment);
            fTrans.commit();

        } else {

            noInternetFragment = new NoInternetFragment();
            fTrans = getSupportFragmentManager().beginTransaction();
            fTrans.replace(R.id.content, noInternetFragment);
            fTrans.addToBackStack(null);
            fTrans.show(noInternetFragment);
            fTrans.commit();
        }

    }


    private void goToUser() {

        if (isInternet) {

            userFragment = new UserFragment();
            fTrans = getSupportFragmentManager().beginTransaction();
            fTrans.replace(R.id.content, userFragment);
            fTrans.addToBackStack(null);
            fTrans.show(userFragment);
            fTrans.commit();

        } else {

            noInternetFragment = new NoInternetFragment();
            fTrans = getSupportFragmentManager().beginTransaction();
            fTrans.replace(R.id.content, noInternetFragment);
            fTrans.addToBackStack(null);
            fTrans.show(noInternetFragment);
            fTrans.commit();
        }

    }


    private void goAbout() {

        settingsFragment = new SettingsFragment();
        fTrans = getSupportFragmentManager().beginTransaction();
        fTrans.replace(R.id.content, settingsFragment);
        fTrans.addToBackStack(null);
        fTrans.show(settingsFragment);
        fTrans.commit();
    }


    private void goRecords() {

        recordsFragment = new RecordsFragment();
        fTrans = getSupportFragmentManager().beginTransaction();
        fTrans.replace(R.id.content, recordsFragment);
        fTrans.addToBackStack(null);
        fTrans.show(recordsFragment);
        fTrans.commit();

    }


    @Override
    public void onBackPressed() {
    }

    public void changeBack(Palette palette){

        main.setBackgroundColor(palette.getVibrantColor(0));

    }

}
