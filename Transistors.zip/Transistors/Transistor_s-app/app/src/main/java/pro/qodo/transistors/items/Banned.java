package pro.qodo.transistors.items;

import com.parse.ParseClassName;
import com.parse.ParseObject;
import com.parse.ParseQuery;



@ParseClassName("Banned")
public class Banned extends ParseObject {

    public static String BANNED_USER = "user";
    public static ParseQuery<Banned> getBannedUser() {
        return new ParseQuery<Banned>(Banned.class);
    }

    public void setBannedUser(User user){
        put(BANNED_USER,user);
    }

    public User getBannUser(){

        return (User) this.getParseUser(BANNED_USER);

    }

}
