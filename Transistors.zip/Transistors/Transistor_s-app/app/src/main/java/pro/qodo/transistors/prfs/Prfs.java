package pro.qodo.transistors.prfs;

public interface Prfs {


    Boolean ADS_OFF = false;
    Boolean AUTOSTART = true;
    String W_FB = "https://www.facebook.com/djmagazine";
    String W_TW = "https://twitter.com/DJmag";
    String W_SITE = "https://djmag.com/";
    String LIVE_QUERY_HOSTING = "wss://transistortst.b4a.io";
    String COVER = "https://cdn.pixabay.com/photo/2018/05/29/23/36/cd-cover-3440399_960_720.jpg";

    Boolean RECORD_DATA = false; // false - off / true - make demo !!!!


    //// NOT CHANGE !!!

    String APPNAME = "Transistor";
    String NAME_ARTIST = "artist";
    String TITLE_RADIO = "title";
    String COWNTDOWN = "count";
    String FOLDER_REC = "/Records/";
    String COVER_RADIO = "cover";
    boolean RESUME_RADIO_ON_PHONE_CALL = true;

}
