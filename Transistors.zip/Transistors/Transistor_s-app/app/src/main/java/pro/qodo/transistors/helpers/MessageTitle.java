package pro.qodo.transistors.helpers;

public class MessageTitle {

    public final String message;



    public MessageTitle(String message) {
        this.message = message;



    }

}
