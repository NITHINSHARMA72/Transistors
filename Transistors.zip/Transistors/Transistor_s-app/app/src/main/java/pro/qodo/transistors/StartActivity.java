package pro.qodo.transistors;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import androidx.appcompat.widget.Toolbar;

import com.airbnb.lottie.LottieAnimationView;
import com.appizona.yehiahd.fastsave.FastSave;
import com.jaeger.library.StatusBarUtil;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseQuery;
import com.parse.SaveCallback;

import java.io.ByteArrayOutputStream;
import java.util.List;

import pro.qodo.transistors.items.Radio;
import pro.qodo.transistors.prfs.Prfs;
import pro.qodo.transistors.singleton.RadioGlobal;



public class StartActivity extends BaseActivity  implements Prfs {

    private Toolbar mToolbar;
    private View mViewNeedOffset;
    Radio radio;
    ParseFile photo;
    LottieAnimationView lottieAnimationView;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        StatusBarUtil.setTranslucentForImageView(StartActivity.this, 0, mViewNeedOffset);
        StatusBarUtil.setLightMode(StartActivity.this);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        mViewNeedOffset = findViewById(R.id.view_need_offset);
        lottieAnimationView = (LottieAnimationView) findViewById(R.id.animation_view);


        if (isOnline()){


            if(RECORD_DATA){

                recordData();
            } else {

                getRadio();
            }

            FastSave.getInstance().saveBoolean("internet",true);

        } else {

            FastSave.getInstance().saveBoolean("internet",false);


            gotomainWithoutInternet();
        }




    }

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }


    private void getRadio() {


        ParseQuery<Radio> rQuery = Radio.getAppRadio();
        rQuery.findInBackground(new FindCallback<Radio>() {
            @Override
            public void done(List<Radio> objects, ParseException e) {

                if (e == null) {
                    radio = new Radio();
                    radio = objects.get(0);
                    RadioGlobal.getInstance().setRadio(radio);
                    gotoMain();

                } else {

                    System.out.println("SSS - ER --  " + e.getLocalizedMessage());
                }

            }
        });

    }


    private void gotoMain() {

        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                startActivity(intent);

                overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
                lottieAnimationView.setVisibility(View.INVISIBLE);

            }
        }, 5000);

    }

    private void gotomainWithoutInternet(){

        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
                lottieAnimationView.setVisibility(View.INVISIBLE);

            }
        }, 5000);

    }

    private void recordData(){


        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.logo);

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] image = stream.toByteArray();

        photo = new ParseFile("userpicture.png", image);

        photo.saveInBackground(new SaveCallback() {
            public void done(ParseException e) {

                makeData();

              //  System.out.println("SSS eee- - -  " + e.getLocalizedMessage());

            }
        });


    }

    private void makeData(){


        Radio radios = new Radio();
        radios.setImage(photo);
        radios.setRating(0);
        radios.setVoites(0);
        radios.setrName("My radio station");
        radios.setrUrl("http://air2.radiorecord.ru:9003/fut_320");
        radios.saveInBackground(new SaveCallback() {
            @Override
            public void done(ParseException e) {

                RadioGlobal.getInstance().setRadio(radios);

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        gotoMain();
                    }
                },1000);
            }
        });


    }

}
