package pro.qodo.transistors.items;

import com.parse.ParseClassName;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;



@ParseClassName("Radio")
public class Radio extends ParseObject {

    public static String R_NAME = "name";
    public static String R_URL = "urlRadio";
    public static String R_LOGO = "logo";
    public static String R_VOITING = "voiting";
    public static String R_RATING = "rating";


    public static ParseQuery<Radio> getAppRadio() {
        return new ParseQuery<Radio>(Radio.class);
    }


    public String getrName() {

        return this.getString(R_NAME);
    }


    public void setrName(String name) {
        put(R_NAME, name);
    }


    public String getrUrl() {
        return this.getString(R_URL);
    }


    public void setrUrl(String url) {
        put(R_URL, url);
    }


    public void setImage(ParseFile image) {
        put(R_LOGO, image);
    }


    public String getImageUrl() {
        String imageUrl = "";
        if (this.getParseFile(R_LOGO) != null) {
            imageUrl = this.getParseFile(R_LOGO).getUrl();
        }
        return imageUrl;
    }


    public void setRating(int tvRating) {
        put(R_RATING, tvRating);
    }


    public int getRating() {
        return this.getInt(R_RATING);
    }


    public void setVoites(int tvVoites) {
        put(R_VOITING, tvVoites);
    }


    public int getVoites() {
        return this.getInt(R_VOITING);
    }

}
