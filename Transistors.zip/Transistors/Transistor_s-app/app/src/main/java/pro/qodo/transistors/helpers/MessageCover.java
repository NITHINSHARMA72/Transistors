package pro.qodo.transistors.helpers;

import android.graphics.Bitmap;

public class MessageCover {


    public final String cover;
    public final Bitmap bitmap;


    public MessageCover( String cover, Bitmap bitmap) {

        this.cover = cover;
        this.bitmap = bitmap;


    }

}
