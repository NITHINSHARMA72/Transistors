package pro.qodo.transistors.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import butterknife.BindView;
import butterknife.ButterKnife;
import pro.qodo.transistors.MainActivity;
import pro.qodo.transistors.R;
import pro.qodo.transistors.dialog.NameDialog;
import pro.qodo.transistors.items.User;



/**
 * A simple {@link Fragment} subclass.
 */
public class UserFragment extends Fragment {

    View rootView;
    @BindView(R.id.tv_username)
    TextView user_name;
    @BindView(R.id.btn_change)
    Button btn_change;
    @BindView(R.id.btn_logout)
    Button logout_btn;
    User user;


    public UserFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_user, container, false);
        ButterKnife.bind(this, rootView);

        user = (User) ParseUser.getCurrentUser();

        try {

            user_name.setText(getString(R.string.you_name)+" " + user.fetchIfNeeded().getString("nickname"));

        } catch (com.parse.ParseException e) {

        }

        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final NameDialog n = new NameDialog(getActivity());
                n.show();
                n.findViewById(R.id.btn_change).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String newName = n.text.getText().toString();
                        if (newName.isEmpty() ) {

                        } else {

                            user.setUserNikname(newName);
                          //  user.setUserAsAdmin(true);     /// AFTER SET AS ADMIN - COMMENT THIS LINE!!!!!!!!!
                            user.saveInBackground(new SaveCallback() {
                                @Override
                                public void done(ParseException e) {

                                    n.dismiss();
                                    newName();

                                }
                            });
                        }
                    }
                });
            }
        });

        logout_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ParseUser.logOutInBackground(new LogOutCallback() {
                    @Override
                    public void done(ParseException e) {

                    }
                });
                ParseUser.logOut();

                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);

            }
        });

        return rootView;
    }


    public void newName() {

        user = (User) ParseUser.getCurrentUser();

        try {

            user_name.setText(getString(R.string.you_name) +" "+ user.fetchIfNeeded().getString("nickname"));

        } catch (com.parse.ParseException e) {

        }

    }

}
