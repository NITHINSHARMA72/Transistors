package pro.qodo.transistors.dialog;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatDialog;
import pro.qodo.transistors.R;



public class NameDialog extends AppCompatDialog implements
        View.OnClickListener {

    public Activity df;
    public EditText text;
    Button ok;


    public NameDialog(Activity a) {
        super(a);
        this.df = a;

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.name_dialog);
        text = (EditText) findViewById(R.id.name_edit_txt);
        ok = (Button) findViewById(R.id.btn_change);
        getWindow().setGravity(Gravity.CENTER);
        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_change:
                break;

            default:
                break;
        }
        dismiss();
    }

}