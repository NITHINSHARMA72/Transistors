package pro.qodo.transistors;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import androidx.appcompat.widget.Toolbar;

import com.flaviofaria.kenburnsview.KenBurnsView;
import com.jaeger.library.StatusBarUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import pro.qodo.transistors.loginScreen.LoginParseActivity;
import pro.qodo.transistors.loginScreen.RegisterParseActivity;



public class UpActivity extends BaseActivity {

    @BindView(R.id.toolbar)
    Toolbar mToolbar;
    @BindView(R.id.view_need_offset)
    View mViewNeedOffset;
    @BindView(R.id.btn_loginz)
    Button login_btn;
    @BindView(R.id.btn_register)
    Button register_btn;
   // @BindView(R.id.txt_login_phone)
   // TextView phone_login;
    @BindView(R.id.image1)
    KenBurnsView motion_cover;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_up);
        ButterKnife.bind(this);

        StatusBarUtil.setTranslucentForImageView(UpActivity.this, 0, mViewNeedOffset);
        StatusBarUtil.setLightMode(UpActivity.this);

        motion_cover.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));


        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent lo = new Intent(UpActivity.this, LoginParseActivity.class);
                startActivity(lo);

            }
        });

        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent re = new Intent(UpActivity.this, RegisterParseActivity.class);
                startActivity(re);

            }
        });

      /*  phone_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent go = new Intent(UpActivity.this, PhoneLoginActivity.class);
                startActivity(go);
            }
        }); */

    }

}
