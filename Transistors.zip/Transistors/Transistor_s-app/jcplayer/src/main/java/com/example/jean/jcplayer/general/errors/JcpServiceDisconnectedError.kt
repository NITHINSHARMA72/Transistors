package com.example.jean.jcplayer.general.errors

/**
 * @author Jean Carlos (Github: @jeancsanchez)
 * @date 01/05/18.
 * Jesus loves you.
 */
object JcpServiceDisconnectedError : Throwable()